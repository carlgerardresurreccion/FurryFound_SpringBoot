package com.furryfound.ffbackend.service;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
public class Hey {

    @RequestMapping("/hello")
    public String hello(){
        return "Hello World";
    }
}