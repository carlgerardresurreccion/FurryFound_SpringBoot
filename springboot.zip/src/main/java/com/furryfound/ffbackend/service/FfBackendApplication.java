package com.furryfound.ffbackend.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FfBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FfBackendApplication.class, args);
	}

}
