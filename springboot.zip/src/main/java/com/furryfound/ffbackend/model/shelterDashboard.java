package com.furryfound.ffbackend.model;

import java.util.List;

@Entity
public class shelterDashboard {

    private List<Pet> petListings;

    private List<Pet> archivedPets;

    private List<Application> applicationsList;

    private List<Application> approvedApplications;

    private List<Application> historyApplications;

 
    public List<Pet> getPetListings() {
        return petListings;
    }

    public List<Pet> getArchivedPets() {
        return archivedPets;
    }

    public List<Application> getApplicationsList() {
        return applicationsList;
    }

    public List<Application> getApprovedApplications() {
        return approvedApplications;
    }

    public List<Application> getHistoryApplications() {
        return historyApplications;
    }

    public void addPetListing(Pet pet) {
        
    }

    public void archivePet(Pet pet) {
        
    }

    public void addApplication(Application application) {
    
    }

    public void approveApplication(Application application) {
        
    }

    public void moveApplicationToHistory(Application application) {
        
    }

}
