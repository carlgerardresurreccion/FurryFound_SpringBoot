package com.furryfound.ffbackend.model;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

public class UserProfile {

    private String userID;
    private String username;
    private String email;
    private String password;
    private String role;

    public UserProfile(){

    }

    public String getuserID(){
        return userID;
    }

    public String getUsername(){
        return username;
    }

    public String getEmail(){
        return email;
    }

    public String getRole(){
        return role;
    }

    public void setPassword(String password){
        this.password = password;
    }
}
