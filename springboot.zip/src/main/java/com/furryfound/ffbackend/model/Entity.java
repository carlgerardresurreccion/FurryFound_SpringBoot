package com.furryfound.ffbackend.model;

public @interface Entity {

}
