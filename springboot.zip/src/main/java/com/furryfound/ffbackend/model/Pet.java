package com.furryfound.ffbackend.model;

import java.util.Date;

@Entity
public class Pet {
    @Id
    private String id;
    private String name;
    private String species;
    private String breed;
    private int age;
    private String gender;
    private Date dateArrived;
    private boolean availableForAdoption;

    public Pet() {
    }

    public Pet(String id, String name, String species, String breed, int age, String gender, Date dateArrived, boolean availableForAdoption) {
        this.id = id;
        this.name = name;
        this.species = species;
        this.breed = breed;
        this.age = age;
        this.gender = gender;
        this.dateArrived = dateArrived;
        this.availableForAdoption = availableForAdoption;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    public String getBreed() {
        return breed;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public Date getDateArrived() {
        return dateArrived;
    }

    public boolean isAvailableForAdoption() {
        return availableForAdoption;
    }

    public void setAvailableForAdoption(boolean available) {
        this.availableForAdoption = available;
    }

}