package com.furryfound.ffbackend.model;

@Entity
public class shelterApplicationResponse {
    private Application application;
    private String responseMessage;
    private boolean isApproved;

    public shelterApplicationResponse(){

    }

    public Application getApplication() {
        return this.application;
    }

    public String getResponseMessage() {
        return this.responseMessage;
    }

    public boolean isApproved() {
        return this.isApproved;
    }
}
