package com.furryfound.ffbackend.model;

public class Application {

}
