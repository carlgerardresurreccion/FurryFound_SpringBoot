package com.furryfound.ffbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FfBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
